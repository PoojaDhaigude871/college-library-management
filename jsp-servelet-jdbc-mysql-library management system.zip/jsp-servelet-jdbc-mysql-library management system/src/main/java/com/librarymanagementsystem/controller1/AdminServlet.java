package com.librarymanagementsystem.controller1;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.librarymanagementsystem.dao.copy.BookDao;
import com.librarymanagementsystem.model.Book;

import java.io.IOException;

public class AdminServlet extends HttpServlet {
    private BookDao bookDao;

    @Override
    public void init() throws ServletException {
        bookDao = new BookDao();
    }
protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
	this.doGet(request, response);
}
		

protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		
		String action =request.getServletPath();
		switch(action) {
		case "/new":
			shownew(request,response);
			break;
		case "/insert":
			insert(request,response);
			break;
		case "/delete":
			break;
		default:
			break;
		}
	}
	
	private void shownew(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		RequestDispatcher dispatcher=request.getRequestDispatcher("books.jsp");
		dispatcher.forward(request, response);
	}

	private void insert(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String isbn = request.getParameter("isbn");
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setQuantity(quantity);

        bookDao.addBook(book);

        response.sendRedirect("admin.jsp");
    }
}

