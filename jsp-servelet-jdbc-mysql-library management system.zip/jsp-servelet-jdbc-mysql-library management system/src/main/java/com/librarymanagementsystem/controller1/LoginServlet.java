package com.librarymanagementsystem.controller1;




import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Sample user data (replace with actual database validation)
        String adminUser = "admin";
        String adminPass = "admin123";
        String librarianUser = "librarian";
        String librarianPass = "lib123";
        String studentUser = "student";
        String studentPass = "student123";

        HttpSession session = request.getSession();

        if (username.equals(adminUser) && password.equals(adminPass)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "admin");
            response.sendRedirect("admin.jsp");
        } else if (username.equals(librarianUser) && password.equals(librarianPass)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "librarian");
            response.sendRedirect("librarian.jsp"); // Create and implement `librarian.jsp` page
        } else if (username.equals(studentUser) && password.equals(studentPass)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "student");
            response.sendRedirect("books.jsp"); // Direct students to the book list
        } else {
            request.setAttribute("errorMessage", "Invalid username or password");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}

